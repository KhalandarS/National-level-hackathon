# README.md

# Agro Ally - Plant Disease Detection

**Agro Ally** is a web application that allows farmers to detect plant diseases by uploading an image of a plant leaf. The application predicts the disease and suggests preventive measures.

## Features
- Image upload for plant disease detection.
- Disease detection with preventive measures.
- Image preview for easy verification before submission.

## Technologies Used
- **HTML/CSS**: For the structure and style of the web interface.
- **JavaScript (Fetch API, FileReader API)**: For file handling, asynchronous requests, and dynamic updates.
- **Python (Flask)**: Backend framework for handling image uploads and disease detection.
- **REST API**: Facilitates communication between frontend and backend.

## Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/yourusername/Agro-Ally.git
   cd Agro-Ally
