from fastapi import FastAPI, File, UploadFile
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import random
import uvicorn

app = FastAPI()

# Mount static files and templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Mock disease data
DISEASES = [
    {"name": "Leaf Spot", "recommendation": "Use a fungicide and avoid overhead watering."},
    {"name": "Blight", "recommendation": "Remove infected leaves and use a copper-based spray."},
    {"name": "Mildew", "recommendation": "Apply a fungicide and increase air circulation."},
    {"name": "Rust", "recommendation": "Trim affected areas and apply sulfur-based treatments."}
]

@app.get("/", response_class=HTMLResponse)
async def read_root():
    return templates.TemplateResponse("index.html", {"request": {}})

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    # Mock prediction logic
    disease = random.choice(DISEASES)
    return {"disease": disease["name"], "recommendation": disease["recommendation"]}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
    