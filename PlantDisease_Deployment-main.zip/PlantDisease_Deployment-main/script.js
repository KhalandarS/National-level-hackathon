document.getElementById('uploadForm').onsubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('file', document.getElementById('fileInput').files[0]);
    const preventiveMeasure = document.getElementById('preventiveMeasure').value;
    formData.append('preventiveMeasure', preventiveMeasure);

    document.getElementById('loader').style.display = 'block'; // Show loader
    document.getElementById('result').style.display = 'none'; // Hide result initially

    try {
        const response = await fetch('/predict', {
            method: 'POST',
            body: formData
        });

        // Check if the response is OK
        if (response.ok) {
            const result = await response.json();
            console.log(result); // Log the result for debugging
            
            document.getElementById('loader').style.display = 'none'; // Hide loader
            document.getElementById('result').innerHTML = `
                <h2>Result:</h2>
                <p>Disease Detected: ${result.disease ? result.disease : 'N/A'}</p>
                <p>Preventive Measures: ${result.preventiveMeasures ? result.preventiveMeasures : 'N/A'}</p>
            `;
            document.getElementById('result').style.display = 'block'; // Show result
        } else {
            throw new Error('Network response was not ok');
        }
    } catch (error) {
        document.getElementById('loader').style.display = 'none'; // Hide loader
        document.getElementById('result').innerHTML = `
            <h2>Error:</h2>
            <p>Unable to process the request: ${error.message}</p>
        `;
        document.getElementById('result').style.display = 'block'; // Show error message
    }
};
